#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from pv_mvp.detect import detect_image
from pv_mvp.io_utils import ensure_dir
from pv_mvp.report import write_review_html, write_summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Step 2: detect suspected PV and rough roof potential.")
    parser.add_argument("--input", type=Path, default=PROJECT_ROOT / "outputs" / "poi_resolved.csv")
    parser.add_argument("--output-dir", type=Path, default=PROJECT_ROOT / "outputs")
    parser.add_argument("--limit", type=int, default=0)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = ensure_dir(args.output_dir)
    poi_rows = pd.read_csv(args.input, encoding="utf-8-sig")
    if args.limit:
        poi_rows = poi_rows.head(args.limit)

    rows = []
    for _, row in tqdm(poi_rows.iterrows(), total=len(poi_rows), desc="detect pv + potential"):
        if row.get("image_status") != "ok" or not str(row.get("image_path") or "").strip():
            continue
        detection = detect_image(
            mall_id=str(row.get("mall_id") or ""),
            name=str(row.get("name") or ""),
            image_path=str(row.get("image_path")),
            output_dir=output_dir,
        ).to_dict()
        merged = row.to_dict()
        merged.update(detection)
        rows.append(merged)

    results = pd.DataFrame(rows)
    output_path = output_dir / "mall_pv_potential_results.csv"
    results.to_csv(output_path, index=False, encoding="utf-8-sig")
    if not results.empty:
        write_summary(results, output_dir)
        write_review_html(results, output_dir)
    print(f"Wrote {output_path}")


if __name__ == "__main__":
    main()
